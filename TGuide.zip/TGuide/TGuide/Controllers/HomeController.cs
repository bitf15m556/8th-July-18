﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace TGuide.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Login()
        {
            return View();
        }
        public ActionResult Register()
        {
            return View();
        }
        public ActionResult User()
        {
            return View();
        }
        public ActionResult Suggest()
        {
            return View();
        }
        public ActionResult Suggestions()
        {
            return View();
        }
        public ActionResult Favorites()
        {
            return View();
        }
        public ActionResult History()
        {
            return View();
        }
        public ActionResult Guide1()
        {
            return View();
        }
    }
}
